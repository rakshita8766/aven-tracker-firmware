/*
 * @file    : lte_driver.c
 * @project : AVEN Tracker
 * @brief   : AT command driver for EC200U-CN LTE module
 * @date    : 2026-04-23
 * @status  : WORKING — DO NOT CHANGE CORE SETTINGS
 *
 * Confirmed working:
 *   - Jio LTE India (IPv6: 2409:40F2:...)
 *   - IPV4V6 PDP type, QICSGP type 3
 *   - EMQX broker.emqx.io port 1883
 *   - MQTT connected + publish confirmed
 */

#include "lte_driver.h"
#include <stdio.h>

#define RX_BUF_SIZE 512
static char rx_buf[RX_BUF_SIZE];

/* LTE_WaitFor (keep reading data from uart untill specific response is received or timeout hppens*/
static uint8_t LTE_WaitFor(UART_HandleTypeDef *huart, //which uart to use
                            const char *target, //the string we ae waiting for(ok, error, ready)
                            char *out_buf, //Buffer to store received data
                            uint16_t out_size, //Size of buffer to avoid overflow)
                            uint32_t timeout_ms)// how long to wait(ms)
{
    uint32_t start = HAL_GetTick();
    uint16_t idx = 0; // to track pos in buff,where to store nxt char, starting from 0
    memset(out_buf, 0, out_size);

    while ((HAL_GetTick() - start) < timeout_ms)
    {
        uint8_t ch;
        if (HAL_UART_Receive(huart, &ch, 1, 50) == HAL_OK)
        {
            if (idx < out_size - 1)
                out_buf[idx++] = ch;
            if (strstr(out_buf, target) != NULL)
                return 1;
        }
    }
    return 0;
}

/* LTE_SendAT */
AvenStatus_t LTE_SendAT(UART_HandleTypeDef *huart,
                         const char *cmd,
                         char *response,
                         uint32_t timeout_ms)
{
    memset(rx_buf, 0, RX_BUF_SIZE);
    HAL_UART_Transmit(huart, (uint8_t *)cmd, strlen(cmd), 1000);

    uint32_t start = HAL_GetTick();
    uint16_t idx = 0;

    while ((HAL_GetTick() - start) < timeout_ms)
    {
        uint8_t ch;
        if (HAL_UART_Receive(huart, &ch, 1, 100) == HAL_OK)
        {
            if (idx < RX_BUF_SIZE - 1)
                rx_buf[idx++] = ch;
            if (strstr(rx_buf, "OK\r\n")  != NULL ||
                strstr(rx_buf, "ERROR")   != NULL ||
                strstr(rx_buf, ">")       != NULL)
                break;
        }
    }
    rx_buf[idx] = '\0';//end the string properly, needed for string fun(printf,strstr)

    if (response != NULL)
    {
        strncpy(response, rx_buf, RX_BUF_SIZE - 1);
        response[RX_BUF_SIZE - 1] = '\0';
    }
    return (strstr(rx_buf, "OK") != NULL) ? AVEN_OK : AVEN_ERROR;
}

/* LTE_Init */
AvenStatus_t LTE_Init(UART_HandleTypeDef *huart)
{
    char resp[RX_BUF_SIZE];

    LTE_SendAT(huart, "AT\r\n",              resp, 300); HAL_Delay(200);//check module
    LTE_SendAT(huart, "ATE0\r\n",            resp, 300); HAL_Delay(200);//disable echo
    LTE_SendAT(huart, "AT+CMEE=2\r\n",       resp, 300); HAL_Delay(200);//detailed errors
    LTE_SendAT(huart, "AT+QCFG=\"ims\",1\r\n", resp, 300); HAL_Delay(200);//config

    printf("LTE Init OK\r\n");
    return AVEN_OK;
}

/* LTE_ActivateData
 * WORKING CONFIG — IPV4V6 + QICSGP type 3 + module reset */
AvenStatus_t LTE_ActivateData(UART_HandleTypeDef *huart)
{
    char resp[RX_BUF_SIZE];

    /* Reset module for clean state */
    printf("Resetting module...\r\n");
    LTE_SendAT(huart, "AT+CFUN=1,1\r\n", resp, 15000);
    HAL_Delay(8000);

    /* Wait for network registration */
    printf("Waiting for network...\r\n");
    for (int i = 0; i < 30; i++)
    {
        memset(resp, 0, sizeof(resp));
        LTE_SendAT(huart, "AT+CEREG?\r\n", resp, 300);
        printf("CEREG: %s\r\n", resp);

        if (strstr(resp, "+CEREG: 0,1") != NULL ||
            strstr(resp, "+CEREG: 0,5") != NULL)
        {
            printf("NETWORK OK\r\n");
            break;
        }
        HAL_Delay(2000);
    }

    /* Set PDP context — IPV4V6 confirmed working for Jio,APN */
    memset(resp, 0, sizeof(resp));
    LTE_SendAT(huart, "AT+CGDCONT=1,\"IPV4V6\",\"jionet\"\r\n", resp, 3000);
    printf("CGDCONT: %s\r\n", resp);
    HAL_Delay(500);

    /* QICSGP type 3 = IPv4v6, auth 0 = none — CONFIRMED WORKING */
    memset(resp, 0, sizeof(resp));
    LTE_SendAT(huart, "AT+QICSGP=1,3,\"jionet\",\"\",\"\",0\r\n", resp, 3000);
    printf("QICSGP: %s\r\n", resp);
    HAL_Delay(500);

    /* Activate — retry 3 times */
    for (int i = 0; i < 3; i++)
    {
        printf("QIACT attempt %d...\r\n", i + 1);

        memset(resp, 0, sizeof(resp));
        LTE_SendAT(huart, "AT+QIACT=1\r\n", resp, 150000);
        printf("ACT: %s\r\n", resp);
        HAL_Delay(1000);

        memset(resp, 0, sizeof(resp));
        LTE_SendAT(huart, "AT+QIACT?\r\n", resp, 300); //check ip
        printf("IP: %s\r\n", resp);

        if (strstr(resp, "+QIACT:") != NULL)
        {
            printf("DATA OK\r\n");
            return AVEN_OK;
        }
        LTE_SendAT(huart, "AT+QIDEACT=1\r\n", resp, 40000);
        HAL_Delay(3000);
    }
    printf("DATA FAILED\r\n");
    return AVEN_ERROR;
}
/* LTE_ConfigSSL */
AvenStatus_t LTE_ConfigSSL(UART_HandleTypeDef *huart)
{
    char resp[RX_BUF_SIZE];

    printf("Configuring SSL Context 2...\r\n");

    /* Point context 1 to the CA cert stored in UFS */
    LTE_SendAT(huart, "AT+QSSLCFG=\"cacert\",2,\"UFS:cacert.pem\"\r\n",
               resp, 300); HAL_Delay(200);
    printf("cacert: %s\r\n", resp);

    /* seclevel 1 = verify server certificate (standard for TLS brokers) */
    LTE_SendAT(huart, "AT+QSSLCFG=\"seclevel\",2,0\r\n",resp, 300);
    HAL_Delay(100);
    printf("seclevel: %s\r\n", resp);

    /* TLS 1.2 — value 4 per Quectel EC200U AT manual */
    LTE_SendAT(huart, "AT+QSSLCFG=\"sslversion\",2,4\r\n",resp, 300);
    HAL_Delay(100);
    printf("sslversion: %s\r\n", resp);

    /* SNI = 1 — required for cloud brokers (AWS, Azure, HiveMQ, etc.) */
    LTE_SendAT(huart, "AT+QSSLCFG=\"sni\",2,1\r\n",resp, 300);
    HAL_Delay(100);
    printf("sni: %s\r\n", resp);

    /* ignorelocaltime = 1 — prevents cert rejection due to RTC drift */
    LTE_SendAT(huart, "AT+QSSLCFG=\"ignorelocaltime\",2,1\r\n",resp, 300);
    HAL_Delay(100);
    printf("ignorelocaltime: %s\r\n", resp);

    printf("SSL Config OK\r\n");
    return AVEN_OK;
}

/* LTE_ConnectMQTT_TLS */
AvenStatus_t LTE_ConnectMQTT_TLS(UART_HandleTypeDef *huart)
{
    char resp[RX_BUF_SIZE];
    char cmd[128];

    /* Bind SSL context 1 to MQTT client 0 */
    LTE_SendAT(huart, "AT+QMTCFG=\"SSL\",0,1,2\r\n",     resp, 300); HAL_Delay(200);
    LTE_SendAT(huart, "AT+QMTCFG=\"pdptype\",0,2\r\n",   resp, 300); HAL_Delay(200);
    LTE_SendAT(huart, "AT+QMTCFG=\"pdpcontext\",0,1\r\n",    resp, 300); HAL_Delay(200);
    LTE_SendAT(huart, "AT+QMTCFG=\"version\",0,5\r\n",   resp, 300); HAL_Delay(200);
    LTE_SendAT(huart, "AT+QMTCFG=\"keepalive\",0,60\r\n",resp, 300); HAL_Delay(200);

    /* Close any stale connection */
    LTE_SendAT(huart, "AT+QMTCLOSE=0\r\n", resp, 3000);
    HAL_Delay(2000);

    /* Open TLS connection to your private broker */
    printf("Opening MQTT TLS...\r\n");
    snprintf(cmd, sizeof(cmd),
                 "AT+QMTOPEN=0,\"%s\",%d\r\n", MQTT_BROKER, MQTT_PORT);
        LTE_SendAT(huart, cmd, resp, 5000);

        memset(resp, 0, sizeof(resp));
        if (!LTE_WaitFor(huart, "+QMTOPEN: 0,0", resp, sizeof(resp), 20000))
        {
            printf("MQTT TLS Open failed: %s\r\n", resp);
            return AVEN_ERROR;
        }
        printf("MQTT TLS Open OK\r\n");
        HAL_Delay(500);

        /* Connect with username + password authentication */
        snprintf(cmd, sizeof(cmd),
                 "AT+QMTCONN=0,\"%s\",\"%s\",\"%s\"\r\n",
                 MQTT_CLIENT_ID, MQTT_USERNAME, MQTT_PASSWORD);
        HAL_UART_Transmit(huart, (uint8_t *)cmd, strlen(cmd), 1000);

        memset(resp, 0, sizeof(resp));
        if (LTE_WaitFor(huart, "+QMTCONN: 0,0,0", resp, sizeof(resp), 15000))
        {
            printf("MQTT TLS CONNECTED OK\r\n");
            return AVEN_OK;
        }
        printf("MQTT TLS Connect failed: %s\r\n", resp);
            return AVEN_ERROR;
}

/* LTE_PublishData */
AvenStatus_t LTE_PublishData(UART_HandleTypeDef *huart,
                              const char *topic,
                              const char *payload)
{
    char cmd[256];
    char resp[RX_BUF_SIZE];

    /* Step 1: Send publish command */
    int len = strlen(payload);
    snprintf(cmd, sizeof(cmd),
             "AT+QMTPUBEX=0,1,0,0,\"%s\",%d\r\n", topic, len);
    /* Transmit command directly — do NOT use LTE_SendAT here */
    HAL_UART_Transmit(huart, (uint8_t *)cmd, strlen(cmd), 1000);

    /* Step 2: Wait for '>' prompt from module */
    memset(resp, 0, sizeof(resp));
    if (!LTE_WaitFor(huart, ">", resp, sizeof(resp), 300))
    {
        printf("No > prompt: %s\r\n", resp);
        return AVEN_ERROR;
    }
    printf("Got > prompt\r\n");
    HAL_Delay(100);

    /* Step 3: Send payload */
    HAL_UART_Transmit(huart, (uint8_t *)payload, strlen(payload), 3000);

    /* Step 4: Wait for +QMTPUBEX confirmation */
    memset(resp, 0, sizeof(resp));
    if (LTE_WaitFor(huart, "+QMTPUBEX: 0,1,0", resp, sizeof(resp), 10000))
    {
    	char *confirm = strstr(resp, "+QMTPUBEX");
    	if(confirm != NULL)
    		printf("Pub result: %s\r\n", confirm);  // prints only +QMTPUBEX: 0,1,0
    	else
    		printf("Pub result: OK\r\n");
    	printf("PUBLISH OK\r\n");
    	return AVEN_OK;
    }

    printf("PUBLISH FAILED\r\n");
    return AVEN_ERROR;
}
/*
 * LTE_CheckMQTTAlive
 * Returns AVEN_OK if connected, AVEN_ERROR if dropped */
AvenStatus_t LTE_CheckMQTTAlive(UART_HandleTypeDef *huart)
{
    char resp[RX_BUF_SIZE];
    memset(resp, 0, sizeof(resp));
    LTE_SendAT(huart, "AT+QMTCONN?\r\n", resp, 300);
    if (strstr(resp, "0,3") != NULL) return AVEN_OK;///* EC200U returns +QMTCONN: 0,3 when connected */
    if (strstr(resp, "0,0,0") != NULL) return AVEN_OK;///* Also accept fresh connection state */
    return AVEN_ERROR;
}

/*  LTE_DisconnectMQTT */
AvenStatus_t LTE_DisconnectMQTT(UART_HandleTypeDef *huart)
{
    char resp[RX_BUF_SIZE];
    LTE_SendAT(huart, "AT+QMTDISC=0\r\n",  resp, 5000); HAL_Delay(500);
    LTE_SendAT(huart, "AT+QMTCLOSE=0\r\n", resp, 5000); HAL_Delay(500);
    printf("MQTT Disconnected\r\n");
    return AVEN_OK;
}
