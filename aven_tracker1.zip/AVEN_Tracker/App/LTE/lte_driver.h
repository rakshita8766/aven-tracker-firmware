/*
 * @file    : lte_driver.h
 * @project : AVEN Tracker
 * @brief   : AT command driver for EC200U-CN LTE module
 * @date    : 2026-04-23
 * @status  : WORKING — DO NOT CHANGE THESE SETTINGS
 *
 * Working config confirmed:
 *   - Jio LTE India, IPv6 address (2409:...)
 *   - EMQX public broker, port 8883, TLS+username/password auth
 *   - PDP type IPV4V6, QICSGP type 3
 */

#ifndef LTE_DRIVER_H
#define LTE_DRIVER_H

#include "stm32wbxx_hal.h"
#include <string.h>
#include <stdio.h>
#include "main.h"

/* MQTT Broker — EMQX Public (confirmed working with Jio IPv6) */
#define MQTT_BROKER        "broker.emqx.io"
#define MQTT_PORT          8883
#define MQTT_CLIENT_ID     "AVEN_TRACKER_001"
#define MQTT_USERNAME      "AVEN_01"
#define MQTT_PASSWORD      "Aven123"

/* MQTT Topics */
#define MQTT_TOPIC_STATUS  "aven/tracker/status"
#define MQTT_TOPIC_GPS     "aven/tracker/gps"
#define MQTT_TOPIC_CAN     "aven/tracker/can"
#define MQTT_TOPIC_ALERT   "aven/tracker/alert"

/* Status codes */
typedef enum {
    AVEN_OK      = 0,
    AVEN_ERROR   = 1,
    AVEN_TIMEOUT = 2
} AvenStatus_t;

/* Function declarations */
AvenStatus_t LTE_Init(UART_HandleTypeDef *huart);
AvenStatus_t LTE_SendAT(UART_HandleTypeDef *huart,
                         const char *cmd,
                         char *response,
                         uint32_t timeout_ms);
AvenStatus_t LTE_ActivateData(UART_HandleTypeDef *huart);
AvenStatus_t LTE_ConfigSSL(UART_HandleTypeDef *huart);
AvenStatus_t LTE_ConnectMQTT_TLS(UART_HandleTypeDef *huart);
AvenStatus_t LTE_PublishData(UART_HandleTypeDef *huart,
                              const char *topic,
                              const char *payload);
AvenStatus_t LTE_CheckMQTTAlive(UART_HandleTypeDef *huart);
AvenStatus_t LTE_DisconnectMQTT(UART_HandleTypeDef *huart);

#endif /* LTE_DRIVER_H */
