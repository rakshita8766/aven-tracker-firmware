/*
 * @file    : flash_storage.c
 * @project : AVEN Tracker
 * @brief   : Offline data storage using STM32WB55 internal flash
 */

#include "flash_storage.h"

/* Internal helper: wait for flash to be ready */
static void Flash_WaitReady(void)
{
    uint32_t timeout = 1000;
    while(__HAL_FLASH_GET_FLAG(FLASH_FLAG_BSY) && timeout > 0)
    {
        HAL_Delay(1);
        timeout--;// decreases timeout by 1
    }
    HAL_Delay(2);//  Small extra settle time for WB55 flash controller
}
/* Flash_Init */
AvenStatus_t Flash_Init(FlashState_t *state)
{
    memset(state, 0, sizeof(FlashState_t));

    uint8_t count = 0;   // unsent records
    uint8_t dirty = 0;   // sent but not yet erased records
    uint8_t clean = 0;   // erased slots available for writing
    FlashRecord_t rec;

    for(int i = 0; i < FLASH_MAX_RECORDS; i++)
    {
        uint32_t addr = FLASH_STORAGE_START + (i * FLASH_RECORD_SIZE);
        memcpy(&rec, (void *)addr, sizeof(FlashRecord_t));

        if(rec.magic == FLASH_MAGIC && rec.sent == 0)
        {
            count++;   // valid unsent record
        }
        else if(rec.magic == FLASH_MAGIC && rec.sent == 1)
        {
            dirty = 1; // sent record still in flash = dirty
        }
        else if(*(uint32_t *)addr == 0xFFFFFFFF)
        {
            clean++;
        }
    }

    if((dirty || clean == 0) && count == 0)
    {
        printf("No pending records and flash page needs erase\r\n");
        state->initialized = 1;
        Flash_EraseAll(state);
    }

    state->record_count = count;
    state->initialized  = 1;

    printf("Flash init: %d pending records\r\n", count);
    return AVEN_OK;
}

/* Flash_EraseAll */
AvenStatus_t Flash_EraseAll(FlashState_t *state)
{
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_ALL_ERRORS);// Clear any previous flash errors before starting

    HAL_FLASH_Unlock();
    Flash_WaitReady(); // wait before erase

    FLASH_EraseInitTypeDef erase;
    uint32_t page_error = 0;

    erase.TypeErase = FLASH_TYPEERASE_PAGES;
    erase.Page      = FLASH_STORAGE_PAGE; //reserved storage page
    erase.NbPages   = 1;                  // erase only 1 page = 4KB

    HAL_StatusTypeDef status = HAL_FLASHEx_Erase(&erase, &page_error);

    HAL_FLASH_Lock();
    Flash_WaitReady(); // wait after erase before any next operation

    if(status != HAL_OK)
    {
        printf("Flash erase FAILED page_error=0x%08lX\r\n", page_error);
        return AVEN_ERROR;
    }

    state->record_count = 0;
    printf("Flash erased OK\r\n");
    return AVEN_OK;
}

/* Flash_SaveRecord */
AvenStatus_t Flash_SaveRecord(FlashState_t *state, const char *payload)
{
    int slot = -1;

    for(int i = 0; i < FLASH_MAX_RECORDS; i++) // Scan for a clean erased slot (0xFFFFFFFF only)
    {
        uint32_t addr      = FLASH_STORAGE_START + (i * FLASH_RECORD_SIZE);
        uint32_t first_word = *(uint32_t *)addr;

        if(first_word == 0xFFFFFFFF)
        {
            slot = i;
            break;
        }
    }
    if(slot == -1) // Do not erase unsent offline records. Retry after upload frees space.
    {
        printf("Flash full - cannot save record\r\n");
        return AVEN_ERROR;
    }

    /* Build the record in RAM first */
    FlashRecord_t new_rec;
    memset(&new_rec, 0xFF, sizeof(FlashRecord_t)); /* fill with 0xFF = erased state */
    new_rec.magic     = FLASH_MAGIC;
    new_rec.timestamp = HAL_GetTick();
    new_rec.sent      = 0;
    strncpy(new_rec.payload, payload, 235);
    new_rec.payload[235] = '\0';

    /* Clear any flash errors, unlock, wait to settle */
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_ALL_ERRORS);
    HAL_FLASH_Unlock();
    Flash_WaitReady(); // CRITICAL: must wait after unlock on STM32WB55

    uint32_t write_addr = FLASH_STORAGE_START + (slot * FLASH_RECORD_SIZE);
    uint64_t *data      = (uint64_t *)&new_rec;
    uint32_t words      = sizeof(FlashRecord_t) / 8; /* 248 / 8 = 31 */

    for(uint32_t i = 0; i < words; i++)
    {
        HAL_StatusTypeDef status = HAL_FLASH_Program(
                                       FLASH_TYPEPROGRAM_DOUBLEWORD,
                                       write_addr + (i * 8),
                                       data[i]);

        if(status != HAL_OK)
        {
            HAL_FLASH_Lock();
            printf("Flash write FAILED at word %lu error=0x%08lX\r\n",
                   i, HAL_FLASH_GetError());
            return AVEN_ERROR;
        }
    }

    HAL_FLASH_Lock();
    Flash_WaitReady(); // wait after write before any next operation

    state->record_count++;
    printf("Flash saved slot=%d count=%d\r\n", slot, state->record_count);
    return AVEN_OK;
}

/* Flash_ReadRecord */
AvenStatus_t Flash_ReadRecord(FlashState_t *state,
                               uint8_t index,
                               FlashRecord_t *record)
{
    if(index >= FLASH_MAX_RECORDS)
    {
        printf("Flash read: index %d out of range\r\n", index);
        return AVEN_ERROR;
    }

    uint32_t addr = FLASH_STORAGE_START + (index * FLASH_RECORD_SIZE);
    memcpy(record, (void *)addr, sizeof(FlashRecord_t));

    if(record->magic != FLASH_MAGIC)
    {
        return AVEN_ERROR; // empty or zeroed slot
    }

    return AVEN_OK;
}

/* Flash_MarkSent */
AvenStatus_t Flash_MarkSent(FlashState_t *state, uint8_t index)
{
    if(index >= FLASH_MAX_RECORDS)
    {
        printf("MarkSent: index %d out of range\r\n", index);
        return AVEN_ERROR;
    }

    FlashRecord_t rec;  // Verify record exists before marking
    if(Flash_ReadRecord(state, index, &rec) != AVEN_OK)
    {
        printf("MarkSent: no valid record at index %d\r\n", index);
        return AVEN_ERROR;
    }

    /* Zero the entire slot — all 248 bytes — not just first 8 */
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_ALL_ERRORS);
    HAL_FLASH_Unlock();
    Flash_WaitReady();

    uint32_t base_addr = FLASH_STORAGE_START + (index * FLASH_RECORD_SIZE);
    uint64_t zero      = 0;
    uint32_t words     = sizeof(FlashRecord_t) / 8; /* 31 doublewords */

    for(uint32_t i = 0; i < words; i++)
    {
        HAL_StatusTypeDef status = HAL_FLASH_Program(
                                       FLASH_TYPEPROGRAM_DOUBLEWORD,
                                       base_addr + (i * 8),
                                       zero);

        if(status != HAL_OK)
        {
            HAL_FLASH_Lock();
            printf("MarkSent: write FAILED at word %lu\r\n", i);
            return AVEN_ERROR;
        }
    }

    HAL_FLASH_Lock();
    Flash_WaitReady();

    if(state->record_count > 0)
        state->record_count--;

    printf("Flash record %d marked sent count=%d\r\n", index, state->record_count);
    return AVEN_OK;
}
/* Flash_GetCount, Returns number of unsent records currently in flash. */
uint8_t Flash_GetCount(FlashState_t *state)
{
    return state->record_count;
}
