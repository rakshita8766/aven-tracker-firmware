/*
 * @file    : can_driver.c
 * @project : AVEN Tracker
 * @brief   : Dummy CAN driver - returns hardcoded vehicle data
 */

#include "can_driver.h"
#include <stdio.h>
#include <string.h>

/* Hardcoded dummy CAN message */
#define DUMMY_RPM      800
#define DUMMY_VOLTAGE  124  //12.4V stored as integer x10

/* CAN_GetDummyData, Returns one fixed dummy vehicle message */
void CAN_GetDummyData(CANData_t *data)
{
    data->rpm     = DUMMY_RPM;
    data->voltage = DUMMY_VOLTAGE;//will divide by 10 when building payload

    printf("CAN Dummy: RPM=%d VOLT=%d.%dV\r\n",
           data->rpm,
           data->voltage / 10,
           data->voltage % 10);
}

/* CAN_BuildPayload, Builds JSON string from CAN data */
void CAN_BuildPayload(CANData_t *data, char *payload, uint16_t size)
{
    snprintf(payload, size,
        "{\"device\":\"AVEN_001\","
        "\"rpm\":%d,"
        "\"volt\":%d.%d}",
        data->rpm,
        data->voltage / 10,
        data->voltage % 10);
}
