/*
 * @file    : gnss_driver.h
 * @project : AVEN Tracker
 * @brief   : GNSS driver for EC200U-CN built-in GPS
 * @date    : 2026-04-23
 */

#ifndef GNSS_DRIVER_H
#define GNSS_DRIVER_H

#include "stm32wbxx_hal.h"
#include "lte_driver.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* GPS data structure */
typedef struct {
    float    latitude;
    float    longitude;
    float    speed_kmh;
    float    altitude;
    uint8_t  fix_valid;
    char     timestamp[20];
} GnssData_t;

/* Function declarations */
AvenStatus_t GNSS_Init(UART_HandleTypeDef *huart);
AvenStatus_t GNSS_GetLocation(UART_HandleTypeDef *huart,
                               GnssData_t *data);
void         GNSS_BuildPayload(GnssData_t *data,
                                char *payload,
                                uint16_t size);

#endif /* GNSS_DRIVER_H */
