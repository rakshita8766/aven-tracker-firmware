/*
 * @file    : tracker.c
 * @project : AVEN Tracker
 * @brief   : Core tracking logic - ignition, theft, modes
 * @date    : 2026-04-24
 */

#include "tracker.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* Buzzer pin - defined in CubeMX */
#define BUZZER_PORT    GPIOB
#define BUZZER_PIN     GPIO_PIN_0

/* Movement threshold in meters */
//#define MOVEMENT_THRESHOLD_M   20.0f
#define MOVEMENT_THRESHOLD_M   15.0f
/* Tracker_Init, Initialize tracker state */
void Tracker_Init(TrackerState_t *state)
{
    memset(state, 0, sizeof(TrackerState_t));

    state->mode             = MODE_PARKING;
    state->ignition_on      = 0;
    state->theft_detected   = 0;
    state->theft_count      = 0;
    state->mqtt_connected   = 1;
    state->publish_interval = 10000;
    state->last_publish_time = 0;
    state->last_lat         = 0.0f;
    state->last_lon         = 0.0f;

    printf("Tracker initialized - PARKING mode\r\n");
}
void Tracker_ActivateBuzzer(uint8_t on)
{
	static uint8_t current_state = 0;   // track current state
	if(on == current_state) return;     // skip if already in that state
	current_state = on;
    if(on){
    	HAL_GPIO_WritePin(BUZZER_PORT, BUZZER_PIN, GPIO_PIN_SET);
        printf("BUZZER ON\r\n");
    }
    else{
    	HAL_GPIO_WritePin(BUZZER_PORT, BUZZER_PIN, GPIO_PIN_RESET);
        printf("BUZZER OFF\r\n");
    }
}
void Tracker_CheckIgnition(TrackerState_t *state)
{
    /* Read SW1 button */
	GPIO_PinState pin = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_4);
    if(pin == GPIO_PIN_RESET) //BUTTON IS PRESSED-ON
    {
        if(state->ignition_on == 0)
        {
            state->ignition_on      = 1;
            state->mode             = MODE_LIVE_TRACKING;
            state->theft_detected   = 0;      //clear theft when ignition ON
            state->publish_interval = 10000; // 10s when driving
            Tracker_ActivateBuzzer(0); // turn off buzzer
            printf("IGNITION ON - Live tracking\r\n");
        }
    }
    else // button is not pressed-OFF
    {
        if(state->ignition_on == 1)
        {
            state->ignition_on      = 0;
            state->mode             = MODE_PARKING;
            state->theft_detected   = 0;  // clear theft when ignition OFF
            state->publish_interval = 60000;
            Tracker_ActivateBuzzer(0);   // turn off buzzer
            printf("IGNITION OFF - Parking mode\r\n");
            if(state->gps.fix_valid) // Save parked location
            {
                state->last_lat = state->gps.latitude;
                state->last_lon = state->gps.longitude;
                printf("Parking location saved\r\n");
            }
        }
    }
}
/* Tracker_CalcDistance */

static float Tracker_CalcDistance(float lat1, float lon1, float lat2, float lon2)
{ /* Convert to radians roughly */
    float dlat = (lat2 - lat1) * 111320.0f;
    float dlon = (lon2 - lon1) * 111320.0f * 0.85f;

    return sqrtf(dlat * dlat + dlon * dlon); // Pythagorean distance
}

/* Tracker_CheckTheft, Detect unauthorized movement when parked */
void Tracker_CheckTheft(TrackerState_t *state)
{     /* Only check theft in parking mode */
    if(state->mode != MODE_PARKING) return;
    if(state->gps.fix_valid == 0) return; //Need valid GPS fix and saved location
    if(state->last_lat == 0.0f && state->last_lon == 0.0f) return;

    /* Calculate distance from parked location */
    float dist = Tracker_CalcDistance(
                     state->last_lat, state->last_lon,
                     state->gps.latitude, state->gps.longitude);
    if(dist > MOVEMENT_THRESHOLD_M)
    {
    	state->theft_count++;
    	if(state->theft_count >= 5 && state->theft_detected == 0)
        {
            state->theft_detected = 1;
            state->mode           = MODE_THEFT;
            state->publish_interval = 5000;
            printf("THEFT DETECTED! Dist=%.1f m\r\n", dist);
            Tracker_ActivateBuzzer(1); // Activate buzzer
        }
    }
    else
    {
    	state->theft_count = 0;
        if(state->theft_detected == 1)// Back to safe zone
        {
            state->theft_detected = 0;
            state->mode           = MODE_PARKING;
            state->publish_interval = 60000;
            printf("Back to safe zone\r\n");
            Tracker_ActivateBuzzer(0);
        }
    }
}
/* Tracker_BuildPayload, Build JSON payload based on current mode */
static void Tracker_BuildPayload(TrackerState_t *state, char *payload, uint16_t size)
{
    const char *mode_str;
    switch(state->mode)
    {
        case MODE_LIVE_TRACKING: mode_str = "live";    break;
        case MODE_PARKING:       mode_str = "parking"; break;
        case MODE_THEFT:         mode_str = "THEFT";   break;
        default:                 mode_str = "unknown"; break;
    }

    /* Declare all variables here so both if/else branches can use them */
    int lat_d = 0, lat_f = 0;
    int lon_d = 0, lon_f = 0;
    int spd_d = 0, spd_f = 0;
    int dist_d = 0, dist_f = 0;

    if(state->gps.fix_valid)
    {
        lat_d = (int)state->gps.latitude;
        lat_f = (int)((state->gps.latitude - lat_d) * 1000000);
        if(lat_f < 0) lat_f = -lat_f;

        lon_d = (int)state->gps.longitude;
        lon_f = (int)((state->gps.longitude - lon_d) * 1000000);
        if(lon_f < 0) lon_f = -lon_f;

        spd_d = (int)state->gps.speed_kmh;
        spd_f = (int)((state->gps.speed_kmh - spd_d) * 10);
        if(spd_f < 0) spd_f = -spd_f;

        if(state->mode == MODE_THEFT &&
           state->last_lat != 0.0f && state->last_lon != 0.0f)
        {
            float dist = Tracker_CalcDistance(
                             state->last_lat, state->last_lon,
                             state->gps.latitude, state->gps.longitude);
            dist_d = (int)dist;
            dist_f = (int)((dist - dist_d) * 10);
            if(dist_f < 0) dist_f = -dist_f;
        }

        snprintf(payload, size,
            "{\"device\":\"AVEN_001\","
            "\"mode\":\"%s\","
            "\"lat\":%d.%06d,"
            "\"lon\":%d.%06d,"
            "\"spd\":%d.%01d,"
            "\"ign\":%d,"
            "\"theft\":%d,"
            "\"dist\":%d.%01d,"
            "\"fix\":1,"
            "\"ts\":\"%s\"}",
            mode_str,
            lat_d, lat_f,
            lon_d, lon_f,
            spd_d, spd_f,
            state->ignition_on,
            state->theft_detected,
            dist_d, dist_f,
            state->gps.timestamp);
    }
    else
    {
        snprintf(payload, size,
            "{\"device\":\"AVEN_001\","
            "\"mode\":\"%s\","
            "\"ign\":%d,"
            "\"theft\":%d,"
            "\"fix\":0}",
            mode_str,
            state->ignition_on,
            state->theft_detected);
    }
}
/* Tracker_Run, Main tracker loop - call this in while(1) */
void Tracker_Run(TrackerState_t *state, UART_HandleTypeDef *huart)
{
    uint32_t now = HAL_GetTick();
    char payload[256];
    char alert[256];

    /* Step 1: Check ignition */
    Tracker_CheckIgnition(state);

    /* Step 2: Get GPS */
//    if(GNSS_GetLocation(huart, &state->gps) != AVEN_OK)
//    {
//        printf("GPS not ready\r\n");
//    }
    GNSS_GetLocation(huart, &state->gps);  // just call it, no print
    /* Step 3: Check theft */
    Tracker_CheckTheft(state);

    /* Step 4: Publish at interval */
    if((now - state->last_publish_time) >= state->publish_interval)
    {
        state->last_publish_time = now;

        /* Build and publish GPS payload */
        Tracker_BuildPayload(state, payload, sizeof(payload));
        const char *mode_labels[] = {"LIVE", "PARKING", "THEFT"};
        printf("Mode:%s Payload:%s\r\n", mode_labels[state->mode], payload);

        if(state->mqtt_connected)
        {
            if(LTE_PublishData(huart, MQTT_TOPIC_GPS, payload) == AVEN_OK)
            {
                printf("Published OK\r\n");
            }
            else
            {
                printf("Publish failed\r\n");
                state->mqtt_connected = 0;
            }
        }
        /* Send alert if theft detected */
        if(state->theft_detected)
        {
            snprintf(alert, sizeof(alert),
                "{\"device\":\"AVEN_001\","
                "\"alert\":\"THEFT_DETECTED\","
                "\"ign\":%d}",
                state->ignition_on);

            LTE_PublishData(huart, MQTT_TOPIC_ALERT, alert);
            printf("ALERT SENT\r\n");
        }
    }
    /* Step 5: Check MQTT alive */
    if(LTE_CheckMQTTAlive(huart) != AVEN_OK)
    {
        printf("MQTT dropped, reconnecting\r\n");
        if(LTE_ConnectMQTT_TLS(huart) == AVEN_OK)
        {
            state->mqtt_connected = 1;
            printf("MQTT reconnected\r\n");
        }
        else
        {
            state->mqtt_connected = 0;
            printf("MQTT reconnect failed\r\n");
        }
    }
}

