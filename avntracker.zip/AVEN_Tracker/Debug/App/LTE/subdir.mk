################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../App/LTE/lte_driver.c 

OBJS += \
./App/LTE/lte_driver.o 

C_DEPS += \
./App/LTE/lte_driver.d 


# Each subdirectory must supply rules for building sources it contributes
App/LTE/%.o App/LTE/%.su App/LTE/%.cyclo: ../App/LTE/%.c App/LTE/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_NUCLEO_64 -DUSE_HAL_DRIVER -DSTM32WB55xx -c -I../App/Tracker -I../App/OTA -I../App/Storage -I../App/Can -I../Core/Inc -I../App/LTE -I../App/GNSS -I../Drivers/STM32WBxx_HAL_Driver/Inc -I../Drivers/STM32WBxx_HAL_Driver/Inc/Legacy -I../Drivers/BSP/P-NUCLEO-WB55.Nucleo -I../Drivers/CMSIS/Device/ST/STM32WBxx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -std=gnu11 -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-App-2f-LTE

clean-App-2f-LTE:
	-$(RM) ./App/LTE/lte_driver.cyclo ./App/LTE/lte_driver.d ./App/LTE/lte_driver.o ./App/LTE/lte_driver.su

.PHONY: clean-App-2f-LTE

