/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usart.h"
#include "spi.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lte_driver.h"
#include "gnss_driver.h"
#include "tracker.h"
#include "can_driver.h"
#include "flash_storage.h"
#include "ota.h"
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

COM_InitTypeDef BspCOMInit;

/* USER CODE BEGIN PV */
uint32_t last_publish = 0;
uint32_t publish_interval = 10000;  /* 10 seconds for dummy vehicle data */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void PeriphCommonClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#include <stdio.h>
#include <string.h>
/* this sends printf() o/p to debug console, redirected printf to swo for debug logs */
int _write(int file, char *ptr, int len)
{
    for(int i = 0; i < len; i++)
    {
        ITM_SendChar((uint32_t)*ptr++);
    }
    return len;
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config(); // it configures the main MCU clock

  /* Configure the peripherals common clocks */
  PeriphCommonClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_LPUART1_UART_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */

  /* Initialize LEDs */
  BSP_LED_Init(LED_BLUE);
  BSP_LED_Init(LED_GREEN);
  BSP_LED_Init(LED_RED);

  char response[512]; //stores AT commands responses from LTE

  printf("\r\n=== AVEN TRACKER STARTING ===\r\n");
  HAL_Delay(2000);

  /* Step 1: Init LTE module */
  printf("Initializing LTE...\r\n");
  if (LTE_Init(&hlpuart1) != AVEN_OK) //sends basic AT cmds
  {
      printf("LTE INIT FAILED\r\n");
      BSP_LED_On(LED_RED);
      while(1);
  }
  printf("LTE INIT OK\r\n");

  /* Step 2: Network check */
  LTE_SendAT(&hlpuart1, "AT+CPIN?\r\n",  response, 300);//checks SIM status
  printf("CPIN: %s\r\n",  response);
  LTE_SendAT(&hlpuart1, "AT+CSQ\r\n",    response, 300);//signal strength
  printf("CSQ: %s\r\n",   response);
  LTE_SendAT(&hlpuart1, "AT+CREG?\r\n",  response, 300);//network reg/
  printf("CREG: %s\r\n",  response);

  /* Step 3: Activate Jio data */
  printf("Activating Jio data...\r\n");
  if (LTE_ActivateData(&hlpuart1) != AVEN_OK)// connects to jio network
  {
      printf("DATA FAILED\r\n");
      BSP_LED_On(LED_RED);
      while(1);
  }
  printf("DATA OK\r\n");
//  BSP_LED_On(LED_GREEN);
//  HAL_Delay(300);
//  BSP_LED_Off(LED_GREEN);

  /* Step 4: Configure SSL */
    printf("Configuring SSL...\r\n");
    if (LTE_ConfigSSL(&hlpuart1) != AVEN_OK)
    {
        printf("SSL CONFIG FAILED\r\n");
        BSP_LED_On(LED_RED);
        while(1);
    }
    printf("SSL OK\r\n");

  /* Step 5: Connect MQTT */
    printf("Connecting MQTT...\r\n");
    if (LTE_ConnectMQTT_TLS(&hlpuart1) != AVEN_OK)
    {
    	printf("MQTT CONNECT FAILED\r\n");
    	BSP_LED_On(LED_RED);
    	while(1);
    }
    printf("MQTT OK\r\n");
    LTE_Subscribe(&hlpuart1, MQTT_TOPIC_OTA_CMD);//subscribes to ota command topic

  /* Step 6: Send online status */
  LTE_PublishData(&hlpuart1,     // publishes 1st online msg to cloud
      MQTT_TOPIC_STATUS,
      "{\"device\":\"AVEN_001\","
      "\"status\":\"online\","
      "\"fw\":\"1.0.0\"}");

  BSP_LED_On(LED_BLUE);
  /* Step 7: Init GNSS */
  printf("Starting GNSS...\r\n");
  GNSS_Init(&hlpuart1);
  printf("GNSS started\r\n");

  /* Step 8: Init Tracker */
  TrackerState_t tracker; // creates tracker state structure
  Tracker_Init(&tracker); //intializes tracker values
  printf("Tracker ready\r\n");

  /* Step 9: Init Flash Storage */
  FlashState_t flash;//Creates a flash storage state variable
  Flash_Init(&flash);//scans reserved flash area&counts pending offline records
  printf("Flash storage ready\r\n");

  /* Step 10: Init dummy vehicle data */
  CANData_t can_data;//Creates a variable to hold dummy vehicle data
  printf("Dummy vehicle data ready\r\n");

  /* Step 11: Init OTA */
  OtaContext_t ota;//creates ota context variable
  OTA_Init(&ota);
  printf("OTA ready\r\n");

  /* USER CODE END 2 */
  /* Initialize USER push-button, will be used to trigger an interrupt each time it's pressed.*/
  BSP_PB_Init(BUTTON_SW1, BUTTON_MODE_EXTI);// SW1 button (used as ignition)
  BSP_PB_Init(BUTTON_SW2, BUTTON_MODE_EXTI);
  BSP_PB_Init(BUTTON_SW3, BUTTON_MODE_EXTI);

  /* Initialize COM1 port (115200, 8 bits (7-bit data + 1 stop bit), no parity */
  BspCOMInit.BaudRate   = 115200;
  BspCOMInit.WordLength = COM_WORDLENGTH_8B;
  BspCOMInit.StopBits   = COM_STOPBITS_1;
  BspCOMInit.Parity     = COM_PARITY_NONE;
  BspCOMInit.HwFlowCtl  = COM_HWCONTROL_NONE;
  if (BSP_COM_Init(COM1, &BspCOMInit) != BSP_ERROR_NONE)
  {
    Error_Handler();
  }

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  uint32_t now = HAL_GetTick();//gets current time in ms since the STM32 started

	  /* Run tracker */
	  Tracker_Run(&tracker, &hlpuart1, &flash);

	  /* Get dummy vehicle data every 10 seconds */
	  if((now - last_publish) >= publish_interval)//Checks whether enough time has passed
	  {
	      last_publish = now;

	      /* Get dummy vehicle data  */
	      CAN_GetDummyData(&can_data);

	      /* Build dummy payload */
	      char dummy_payload[256];
	      CAN_BuildPayload(&can_data, dummy_payload, sizeof(dummy_payload));

	      /* Check if MQTT connected */
	      if(LTE_CheckMQTTAlive(&hlpuart1) == AVEN_OK)
	      //if(0)
	      {
	          if(LTE_PublishData(&hlpuart1,// tries to publish/send data to cloud
	              MQTT_TOPIC_CAN,
	              dummy_payload) == AVEN_OK)
	          {
	              printf("Dummy payload published OK\r\n");
	              BSP_LED_Toggle(LED_BLUE);
	          }
	          else
	          {
	              printf("Publish failed - saving to flash\r\n");
	              Flash_SaveRecord(&flash, dummy_payload);
	          }
	          /* Send any stored offline records */
	          if(Flash_GetCount(&flash) > 0)//Checks if flash has pending offline records
	          {
	              printf("Sending %d offline records\r\n",
	                     Flash_GetCount(&flash));
	              for(int i = 0; i < FLASH_MAX_RECORDS; i++)//checks all saved records one by one
	              {
	                  FlashRecord_t rec;
	                  if(Flash_ReadRecord(&flash, i, &rec) == AVEN_OK)//reads record flash slot i
	                	  {
	                	  printf("Offline payload: %s\r\n", rec.payload);
	                      if(LTE_PublishData(&hlpuart1,
	                          MQTT_TOPIC_CAN,
	                          rec.payload) == AVEN_OK)//publishes saved offline payload
	                      {
	                    	  if(Flash_MarkSent(&flash, i) == AVEN_OK)
	                    	  {
	                    	      printf("Offline record %d sent\r\n", i);
	                    	  }
	                      }
	                  }
	              }
	          }
	      }
	      else
	      {
	          /* No internet - save to flash */
	          printf("No network - saving to flash\r\n");
	          Flash_SaveRecord(&flash, dummy_payload);

	          LTE_ConnectMQTT_TLS(&hlpuart1);// Reconnect
	      }
	  }
	  /* Check OTA process  */
	  char mqtt_msg[512];
	  memset(mqtt_msg, 0, sizeof(mqtt_msg));
	  if(LTE_ReadMQTTMessage(&hlpuart1, mqtt_msg, sizeof(mqtt_msg)) == AVEN_OK)
	  {
		  printf("MSG received: %s\r\n", mqtt_msg);
	      OTA_CheckCommand(&ota, mqtt_msg); //pass msg to OTA handler
	  }
	  /* Process OTA if update was requested */
	  if(ota.update_requested)//checks if OTA command requested firmware update
	  {
	      printf("Processing OTA...\r\n");
	      OTA_Process(&ota, &hlpuart1);//starts OTA process using LTE module
	  }
	  HAL_Delay(100);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.MSICalibrationValue = RCC_MSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
  RCC_OscInitStruct.PLL.PLLN = 32;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the SYSCLKSource, HCLK, PCLK1 and PCLK2 clocks dividers
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK4|RCC_CLOCKTYPE_HCLK2
                              |RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.AHBCLK2Divider = RCC_SYSCLK_DIV2;
  RCC_ClkInitStruct.AHBCLK4Divider = RCC_SYSCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief Peripherals Common Clock Configuration
  * @retval None
  */
void PeriphCommonClock_Config(void)
{
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Initializes the peripherals clock
  */
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_SMPS;
  PeriphClkInitStruct.SmpsClockSelection = RCC_SMPSCLKSOURCE_HSI;
  PeriphClkInitStruct.SmpsDivSelection = RCC_SMPSCLKDIV_RANGE0;

  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN Smps */

  /* USER CODE END Smps */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
