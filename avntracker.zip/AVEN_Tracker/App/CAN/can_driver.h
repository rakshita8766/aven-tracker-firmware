#ifndef CAN_DRIVER_H
#define CAN_DRIVER_H

#include "stm32wbxx_hal.h"
#include <stdio.h>
#include <string.h>

/* CAN data structure */
typedef struct {
    uint16_t rpm;
    uint16_t voltage;  /* voltage x10, e.g. 124 = 12.4V */
} CANData_t;

/* Functions */
void CAN_GetDummyData(CANData_t *data);
void CAN_BuildPayload(CANData_t *data,
                      char *payload,
                      uint16_t size);

#endif /* CAN_DRIVER_H */
