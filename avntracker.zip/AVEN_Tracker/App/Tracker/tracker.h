/*
 * @file    : tracker.h
 * @project : AVEN Tracker
 * @brief   : Core tracking logic
 */

#ifndef TRACKER_H
#define TRACKER_H

#include "stm32wbxx_hal.h"
#include "lte_driver.h"
#include "gnss_driver.h"
#include "flash_storage.h"

/*Tracking modes*/
typedef enum {
	MODE_LIVE_TRACKING = 0, MODE_PARKING = 1, MODE_THEFT = 2
}
TrackerMode_t ;

/* Tracker state */
typedef struct {
	TrackerMode_t mode;
	uint8_t     ignition_on;
	uint8_t     theft_detected;
	uint8_t     theft_count;
	uint8_t     mqtt_connected;
	uint32_t    publish_interval;
	uint32_t    last_publish_time;
	float       last_lat;
	float       last_lon;
	GnssData_t  gps;
}
TrackerState_t;

/* Functions */
void         Tracker_Init(TrackerState_t *state);
void         Tracker_CheckIgnition(TrackerState_t *state);
void         Tracker_CheckTheft(TrackerState_t *state);
void         Tracker_Run(TrackerState_t *state, UART_HandleTypeDef *huart, FlashState_t *flash);
void         Tracker_ActivateBuzzer(uint8_t on);

#endif /* TRACKER_H */
