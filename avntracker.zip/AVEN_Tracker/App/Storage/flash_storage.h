/*
 * @file    : flash_storage.h
 * @project : AVEN Tracker
 * @brief   : Offline data storage in STM32 internal flash
 * @date    : 2026-04-25
 */

#ifndef FLASH_STORAGE_H
#define FLASH_STORAGE_H

#include "stm32wbxx_hal.h"
#include "lte_driver.h"
#include <string.h>
#include <stdio.h>
#include <assert.h>

#define FLASH_STORAGE_PAGE_SIZE        0x1000         // 4KB per page
#define FLASH_STORAGE_PAGE     127            // last page of 512KB flash
#define FLASH_STORAGE_START    0x0807F000     // reserved 4KB page start
#define FLASH_STORAGE_SIZE     0x1000         // 4KB
#define FLASH_RECORD_SIZE      256            // bytes per record
#define FLASH_MAX_RECORDS      15             // 15 x 256 = 3840

#define FLASH_MAGIC            0xABCD1234

typedef struct {
    uint32_t magic;
    uint32_t timestamp;
    uint8_t  sent;
    uint8_t  reserved[3];
    char     payload[244];
} FlashRecord_t;

/* Compile-time check */
_Static_assert(sizeof(FlashRecord_t) == FLASH_RECORD_SIZE,
              "FlashRecord_t must be exactly 256 bytes");

typedef struct {
    uint8_t  record_count;
    uint8_t  initialized;
} FlashState_t;

/* Functions */
AvenStatus_t Flash_Init(FlashState_t *state);
AvenStatus_t Flash_SaveRecord(FlashState_t *state, const char *payload);
AvenStatus_t Flash_ReadRecord(FlashState_t *state, uint8_t index, FlashRecord_t *record);
AvenStatus_t Flash_MarkSent(FlashState_t *state, uint8_t index);
AvenStatus_t Flash_EraseAll(FlashState_t *state);
uint8_t      Flash_GetCount(FlashState_t *state);

#endif /* FLASH_STORAGE_H */
