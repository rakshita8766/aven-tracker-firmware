/*
 * @file    : gnss_driver.c
 * @project : AVEN Tracker
 * @brief   : GNSS driver for EC200U-CN built-in GPS
 */

#include "gnss_driver.h"

/* GNSS_Init, Turn on GPS inside EC200U */
AvenStatus_t GNSS_Init(UART_HandleTypeDef *huart)
{
    char resp[512];

    /* Turn on GNSS */
    LTE_SendAT(huart, "AT+QGPS=1\r\n", resp, 300);
    printf("GNSS ON: %s\r\n", resp);

    /* Set GNSS output mode */
    LTE_SendAT(huart, "AT+QGPSCFG=\"outport\",\"usbnmea\"\r\n", resp, 300);
    HAL_Delay(2000);
    printf("GNSS Init OK\r\n");
    return AVEN_OK;
}

/* GNSS_GetLocation, Get current GPS location from EC200U */
AvenStatus_t GNSS_GetLocation(UART_HandleTypeDef *huart, GnssData_t *data)
{
    char resp[512];
    char *ptr;

    /* Request location */
    memset(resp, 0, sizeof(resp));
    LTE_SendAT(huart, "AT+QGPSLOC=2\r\n", resp, 1500);
    //printf("GPS RAW: %s\r\n", resp);

    /* Check if fix available */
    if(strstr(resp, "+QGPSLOC:") == NULL)
    {
    	if(data->fix_valid == 1)
    		printf("GPS fix lost\r\n");
    	data->fix_valid = 0;
    	return AVEN_ERROR;
    }
    /*Response format: +QGPSLOC: <UTC>,<lat>,<lon>,<hdop>,<alt>,<fix>,<cog>,<spkm>,<spkn>,<date>,<nsat> */
    ptr = strstr(resp, "+QGPSLOC:");
    if(ptr == NULL)
    {
        data->fix_valid = 0;
        return AVEN_ERROR;
    }

    /* Skip "+QGPSLOC: " */
    ptr += 10;

    /* Parse UTC time */
    char utc[12] = {0};
    int i = 0;
    while(*ptr != ',' && *ptr != '\0' && i < 11) utc[i++] = *ptr++;
    ptr++; /* skip comma */
    strncpy(data->timestamp, utc, sizeof(data->timestamp));

    /* Parse latitude */
    char lat_str[15] = {0};
    i = 0;
    while(*ptr != ',' && *ptr != '\0' && i < 14) lat_str[i++] = *ptr++;
    ptr++;
    data->latitude = atof(lat_str); //converts ascii to float

    /* Parse longitude */
    char lon_str[15] = {0};
    i = 0;
    while(*ptr != ',' && *ptr != '\0' && i < 14) lon_str[i++] = *ptr++;
    ptr++;
    data->longitude = atof(lon_str);

    /* Parse HDOP - skip it */
    while(*ptr != ',' && *ptr != '\0') ptr++;
    ptr++;

    /* Parse altitude */
    char alt_str[10] = {0};
    i = 0;
    while(*ptr != ',' && *ptr != '\0' && i < 9) alt_str[i++] = *ptr++;
    ptr++;
    data->altitude = atof(alt_str);

    /* Skip fix mode */
    while(*ptr != ',' && *ptr != '\0') ptr++;
    ptr++;

    /* Skip COG(course over ground) */
    while(*ptr != ',' && *ptr != '\0') ptr++;
    ptr++;

    /* Parse speed km/h */
    char spd_str[10] = {0};
    i = 0;
    while(*ptr != ',' && *ptr != '\0' && i < 9) spd_str[i++] = *ptr++;
    ptr++;
    data->speed_kmh = atof(spd_str);
    while(*ptr != ',' && *ptr != '\0') ptr++;//Skip spkn = speed in knots
    ptr++;
    if (data->speed_kmh > 150.0f) data->speed_kmh = 0.0f;  // GPS noise filter

    if(data->fix_valid == 0) // only print when fix first acquired
    	printf("GPS fix acquired: LAT:%.6f LON:%.6f SPD:%1f\r\n", data->latitude, data->longitude, data->speed_kmh);
    data->fix_valid = 1;
    return AVEN_OK;
}
/* GNSS_BuildPayload, Build JSON string from GPS data */
void GNSS_BuildPayload(GnssData_t *data,
                        char *payload,
                        uint16_t size)
{
    if(data->fix_valid)
    {
        /* Convert float to int parts manually */
        /* latitude */
        int lat_d = (int)data->latitude;
        int lat_f = (int)((data->latitude - lat_d) * 1000000);
        if(lat_f < 0) lat_f = -lat_f;

        /* longitude */
        int lon_d = (int)data->longitude;
        int lon_f = (int)((data->longitude - lon_d) * 1000000);
        if(lon_f < 0) lon_f = -lon_f;

        /* speed */
        int spd_d = (int)data->speed_kmh;
        int spd_f = (int)((data->speed_kmh - spd_d) * 10);
        if(spd_f < 0) spd_f = -spd_f;

        /* altitude */
        int alt_d = (int)data->altitude;
        int alt_f = (int)((data->altitude - alt_d) * 10);
        if(alt_f < 0) alt_f = -alt_f;

        snprintf(payload, size,
            "{\"device\":\"AVEN_001\","
            "\"lat\":%d.%06d,"
            "\"lon\":%d.%06d,"
            "\"spd\":%d.%01d,"
            "\"alt\":%d.%01d,"
            "\"ts\":\"%s\","
            "\"fix\":1}",
            lat_d, lat_f,
            lon_d, lon_f,
            spd_d, spd_f,
            alt_d, alt_f,
            data->timestamp);
    }
    else
    {
        snprintf(payload, size,
            "{\"device\":\"AVEN_001\","
            "\"fix\":0,"
            "\"status\":\"searching\"}");
    }
}
