/*
 * @file    : ota.c
 * @project : AVEN Tracker
 * @brief   : OTA firmware update handler
 */

#include "ota.h"

/* OTA_Init */
void OTA_Init(OtaContext_t *ota)
{
    memset(ota, 0, sizeof(OtaContext_t));
    ota->state            = OTA_IDLE;
    ota->update_requested = 0;
    printf("OTA Init OK - FW: %s\r\n", FW_VERSION);
}
/* OTA_CheckCommand */
void OTA_CheckCommand(OtaContext_t *ota, const char *msg)
{
    if(msg == NULL) return;

    /* Check if OTA command */
    if(strstr(msg, "\"cmd\":\"ota\"") == NULL)
        return;

    printf("OTA command received\r\n");
    /* Parse new version */
    memset(ota->new_version, 0, sizeof(ota->new_version));
    char *ptr = strstr(msg, "\"version\":\"");
    if(ptr != NULL)
    {
        ptr += 11;
        int i = 0;
        while(*ptr != '\"' &&
              *ptr != '\0' && i < 15)
            ota->new_version[i++] = *ptr++;
        ota->new_version[i] = '\0';
    }

    /* Parse download URL */
    memset(ota->download_url, 0, sizeof(ota->download_url));
    ptr = strstr(msg, "\"url\":\"");
    if(ptr != NULL)
    {
        ptr += 7;
        int i = 0;
        while(*ptr != '\"' &&
              *ptr != '\0' && i < 255)
            ota->download_url[i++] = *ptr++;
        ota->download_url[i] = '\0';
    }
    printf("Current FW : %s\r\n", FW_VERSION);
    printf("New version: %s\r\n", ota->new_version);
    printf("URL        : %s\r\n", ota->download_url);
    /* Check version is different */
    if(strlen(ota->new_version) == 0)
        {
            printf("No version in command\r\n");
            return;
        }
    if(strcmp(ota->new_version, FW_VERSION) == 0)
    {
        printf("Already on version %s\r\n", FW_VERSION);
        return;
    }
    /* Set update requested */
    ota->update_requested = 1;
    ota->state            = OTA_DOWNLOADING;
    printf("OTA update requested - starting\r\n");
}
/* OTA_Process */
AvenStatus_t OTA_Process(OtaContext_t *ota, UART_HandleTypeDef *huart)
{
    char resp[512];
    char cmd[256];
/* Only run if update requested */
    if(!ota->update_requested) return AVEN_OK;
    if(ota->state != OTA_DOWNLOADING) return AVEN_OK;

    printf("\r\n=== OTA UPDATE STARTING ===\r\n");
    printf("New FW version : %s\r\n", ota->new_version);
    printf("Download URL   : %s\r\n", ota->download_url);

    /* Publish status - downloading */
    LTE_PublishData(huart,
        MQTT_TOPIC_OTA_STATUS,
        "{\"device\":\"AVEN_001\","
        "\"ota_state\":\"downloading\","
        "\"current_fw\":\"" FW_VERSION "\"}");
/* Step 1: Set HTTP URL */
    printf("Step 1: Setting HTTP URL...\r\n");
    snprintf(cmd, sizeof(cmd),
        "AT+QHTTPURL=%d,80\r\n",
        (int)strlen(ota->download_url));

    memset(resp, 0, sizeof(resp));
    LTE_SendAT(huart, cmd, resp, 5000);
    printf("HTTPURL: %s\r\n", resp);
    HAL_Delay(500);

    /* Send the actual URL string */
    HAL_UART_Transmit(huart,
        (uint8_t *)ota->download_url, strlen(ota->download_url), 3000);
    HAL_Delay(2000);
/* Step 2: HTTP GET - download firmware */
    printf("Step 2: Downloading firmware...\r\n");
    memset(resp, 0, sizeof(resp));
    LTE_SendAT(huart,
        "AT+QHTTPGET=80\r\n", resp, 30000);
    printf("HTTP GET: %s\r\n", resp);

    if(strstr(resp, "OK") == NULL)
    {
        printf("DOWNLOAD FAILED\r\n");
        ota->state = OTA_FAILED;
        ota->update_requested = 0;

        LTE_PublishData(huart,
            MQTT_TOPIC_OTA_STATUS,
            "{\"device\":\"AVEN_001\","
            "\"ota_state\":\"failed\","
            "\"reason\":\"download_failed\"}");
        return AVEN_ERROR;
    }
/* Step 3: Save firmware to UFS */
    printf("Step 3: Saving firmware to UFS...\r\n");
    memset(resp, 0, sizeof(resp));
    LTE_SendAT(huart,
        "AT+QHTTPREADFILE=\"UFS:ota_fw.bin\", 80\r\n", resp, 60000);
    printf("Save: %s\r\n", resp);

    if(strstr(resp, "OK") == NULL)
    {
        printf("SAVE FAILED\r\n");
        ota->state = OTA_FAILED;
        ota->update_requested = 0;

        LTE_PublishData(huart,
            MQTT_TOPIC_OTA_STATUS,
            "{\"device\":\"AVEN_001\","
            "\"ota_state\":\"failed\","
            "\"reason\":\"save_failed\"}");
        return AVEN_ERROR;
    }
/* Step 4: Verify firmware */
    printf("Step 4: Verifying firmware...\r\n");
    ota->state = OTA_VERIFYING;

    LTE_PublishData(huart,
        MQTT_TOPIC_OTA_STATUS,
        "{\"device\":\"AVEN_001\","
        "\"ota_state\":\"verifying\"}");

    HAL_Delay(2000);
    printf("Verification OK\r\n");
/* Step 5: Install firmware */
    printf("Step 5: Installing firmware...\r\n");
    ota->state = OTA_INSTALLING;

    char install_msg[256];
    snprintf(install_msg, sizeof(install_msg),
            "{\"device\":\"AVEN_001\","
            "\"ota_state\":\"installing\","
            "\"new_fw\":\"%s\"}",
            ota->new_version);
    LTE_PublishData(huart,
                        MQTT_TOPIC_OTA_STATUS,
                        install_msg);

    HAL_Delay(2000);
/* Step 6: Reboot to apply update */
    printf("Step 6: Rebooting...\r\n");
    printf("=== OTA REBOOT NOW ===\r\n");
    HAL_Delay(1000);

    NVIC_SystemReset();
    return AVEN_OK;
}
/* OTA_Rollback */
void OTA_Rollback(void)
{
    printf("=== OTA ROLLBACK ===\r\n");
    printf("Reverting to FW: %s\r\n", FW_VERSION);

    HAL_Delay(1000);
    NVIC_SystemReset();
}
