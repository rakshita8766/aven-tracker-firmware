/*
 * @file    : ota.h
 * @project : AVEN Tracker
 * @brief   : OTA firmware update over MQTT
 */

#ifndef OTA_H
#define OTA_H

#include "stm32wbxx_hal.h"
#include "lte_driver.h"
#include <stdio.h>
#include <string.h>

/* Current firmware version */
#define FW_VERSION   "1.0.0"

/* OTA states */
typedef enum {
    OTA_IDLE        = 0,
    OTA_DOWNLOADING = 1,
    OTA_VERIFYING   = 2,
    OTA_INSTALLING  = 3,
    OTA_SUCCESS     = 4,
    OTA_FAILED      = 5
} OtaState_t;

/* OTA context */
typedef struct {
    OtaState_t state;
    uint8_t    update_requested;
    char       new_version[16];
    char       download_url[256];
} OtaContext_t;

/* MQTT topics */
#define MQTT_TOPIC_OTA_CMD    "aven/tracker/ota/cmd"
#define MQTT_TOPIC_OTA_STATUS "aven/tracker/ota/status"

/* Functions */
void         OTA_Init(OtaContext_t *ota);
void         OTA_CheckCommand(OtaContext_t *ota, const char *msg);
AvenStatus_t OTA_Process(OtaContext_t *ota, UART_HandleTypeDef *huart);
void         OTA_Rollback(void);

#endif /* OTA_H */
